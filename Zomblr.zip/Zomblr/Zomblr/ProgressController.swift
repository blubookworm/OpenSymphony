//
//  ProgressController.swift
//  Zomblr
//
//  Created by JR Cabansag on 5/17/15.
//  Copyright (c) 2015 JR. All rights reserved.
//

import UIKit
import Parse
class ProgressController: UIViewController{
    @IBOutlet weak var milesField: UITextField!
    @IBOutlet weak var yourProgress: UILabel!
    @IBOutlet weak var zombieProgress: UILabel!
    @IBOutlet weak var comment: UILabel!
    var username = "alisonhau"
    var user: PFObject!
    var miles = 0
    var maxMiles = 0
    var minMiles = 0
    var neededMiles = 0
    var zombieMiles = 0
    var data:[PFObject] = []

    func getUser(){
        data = (PFQuery(className: "Users").findObjects() as? [PFObject])!
        var userIndex = NSUserDefaults.standardUserDefaults().integerForKey("Profile")
        username = data[userIndex]["Username"] as! String
        println(username)
    }
    
    override func viewDidLoad() {
        getUser()
        loadValues()
        println("OTHER VIEW")
        updateDisplays()
        super.viewDidLoad()
    }
    @IBAction func addMiles(sender: AnyObject) {
        if(milesField.text != ""){
            miles+=milesField.text.toInt()!
            updateDisplays()
        }
    }
    func updateDisplays(){
        yourProgress.text = String(miles)+" OUT OF "+String(neededMiles)+" MILES"
        zombieProgress.text = "YOUR ZOMBIES HAVE RUN "+String(zombieMiles)+" MILES"
        if(miles >= neededMiles){
            comment.text = "YOU OUTRAN THE ZOMBIES!"
        }
        else{
            comment.text = "RUN FOR YOUR LIFE!"
        }
        println(comment.text)
        
    }
    func saveValues(){
        user.setValue(miles, forKey: "Miles")
        user.saveInBackground()
    }
    func loadValues(){
        user = PFQuery(className: "Users").whereKey("Username", equalTo: username).getFirstObject()
        maxMiles = user.valueForKey("MaxMiles") as! Int
        minMiles = user.valueForKey("MinMiles") as! Int
        miles = user.valueForKey("Miles") as! Int
        zombieMiles = user.valueForKey("ZombieMiles") as! Int
        var zombieCount = (user.valueForKey("Followers") as! Array<String>).count
        neededMiles = minMiles
        if(zombieCount != 0){
        neededMiles = minMiles+(maxMiles-minMiles)*(zombieMiles/zombieCount*1/5)
        }
        println(minMiles)
        if(neededMiles > maxMiles){
            neededMiles = maxMiles
        }
        if(neededMiles < minMiles){
            neededMiles = minMiles
        }
        println(neededMiles)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
