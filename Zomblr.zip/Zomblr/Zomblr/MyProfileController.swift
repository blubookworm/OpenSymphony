//
//  MyProfileController.swift
//  Zomblr
//
//  Created by JR Cabansag on 5/17/15.
//  Copyright (c) 2015 JR. All rights reserved.
//

import Foundation
import UIKit
import Parse

class MyProfileController: UIViewController {
        @IBOutlet weak var usernameDisplay: UILabel!
        @IBOutlet weak var imageborderDisplay: UIImageView!
        @IBOutlet weak var statusDisplay: UIScrollView!
        @IBOutlet weak var imageDisplay: UIImageView!
        @IBOutlet weak var zombiecountDisplay: UILabel!
        @IBOutlet weak var pointsDisplay: UILabel!
        @IBOutlet weak var barDisplay: UIImageView!
        var username = "alisonhau"
        var user: PFObject!
        
        
        override func viewDidLoad() {
            getUser()
            loadValues()
            createShadows()
            super.viewDidLoad()
        }
    func getUser(){
        var data = (PFQuery(className: "Users").findObjects() as? [PFObject])!
        var userIndex = NSUserDefaults.standardUserDefaults().integerForKey("Profile")
        username = data[userIndex]["Username"] as! String
        println(username)
    }
        
        func loadValues(){
            var userQuery = PFQuery(className: "Users")
            user = userQuery.whereKey("Username", equalTo: username.lowercaseString).getFirstObject()
            usernameDisplay.text = username.uppercaseString
            usernameDisplay.sizeToFit()
            var followers = user.valueForKey("Followers") as! Array<String>
            zombiecountDisplay.text = String(followers.count)+" ZOMBIES"
            zombiecountDisplay.layer.opacity = 0.8
            zombiecountDisplay.sizeToFit()
            pointsDisplay.text = String(user.valueForKey("Points") as! Int)+" POINTS"
            pointsDisplay.sizeToFit()
            if(username == "swetakarlekar"){
                imageDisplay.image = UIImage(named: "Sweta")
            }
            else if(username == "alisonhau"){
                imageDisplay.image = UIImage(named: "Alison")
            }
            else if(username == "jrcabansag"){
                imageDisplay.image = UIImage(named: "JR")
            }
            else if(username == "ekewoko"){
                imageDisplay.image = UIImage(named: "Eke")
            }
            else{
                imageDisplay.image = UIImage(named: "Default")
            }
            var statuses = user.valueForKey("Statuses") as! Array<String>
            if(statuses.count != 0){
                statusDisplay.contentSize = CGSize(width: 320, height: 16+91*statuses.count)
                for var i = 0; i < statuses.count; i++
                {
                    var status = statuses[i]
                    var miniArray = status.componentsSeparatedByString("~")
                    createStatus(miniArray[0], date: miniArray[1], index: i)
                }
            }
        }
        func createStatus(message: String, date: String, index: Int){
            var statusView = UIView(frame: CGRect(x: 16, y: 16+91*index, width: 288, height: 75))
            statusView.backgroundColor = UIColor.whiteColor()
            statusView.layer.shadowColor = UIColor.blackColor().CGColor
            statusView.layer.shadowOffset = CGSize(width: 0, height: 0)
            statusView.layer.shadowOpacity = 0.1
            statusView.layer.shadowRadius = 5
            var messageView = UILabel(frame: CGRect(x: 16, y: 35, width: 0, height: 0))
            messageView.text = message
            messageView.sizeToFit()
            messageView.font = UIFont(name: "Century Gothic", size: 13)
            messageView.textColor = UIColor(red:0.71, green:0.71, blue:0.77, alpha:1.0)
            var dateView = UILabel(frame: CGRect(x: 10, y: 7, width: 0, height: 0))
            dateView.text = date
            dateView.sizeToFit()
            dateView.font = UIFont(name: "Century Gothic", size: 13)
            dateView.textColor = UIColor(red:0.77, green:0.77, blue:0.93, alpha:1.0)
            
            statusDisplay.addSubview(statusView)
            statusView.addSubview(messageView)
            statusView.addSubview(dateView)
        }
        func createShadows(){
            imageborderDisplay.layer.shadowColor = UIColor.blackColor().CGColor
            imageborderDisplay.layer.shadowOpacity = 0.25
            imageborderDisplay.layer.shadowRadius = 5
            imageborderDisplay.layer.shadowOffset = CGSize(width: 0, height: 0)
            zombiecountDisplay.layer.shadowColor = UIColor.blackColor().CGColor
            zombiecountDisplay.layer.shadowOpacity = 0.22
            zombiecountDisplay.layer.shadowOffset = CGSize(width: 0, height: 0)
            zombiecountDisplay.layer.shadowRadius = 5
            usernameDisplay.layer.shadowColor = UIColor.blackColor().CGColor
            usernameDisplay.layer.shadowOpacity = 0.22
            usernameDisplay.layer.shadowOffset = CGSize(width: 0, height: 0)
            usernameDisplay.layer.shadowRadius = 5
            pointsDisplay.layer.shadowColor = UIColor.blackColor().CGColor
            pointsDisplay.layer.shadowOpacity = 0.22
            pointsDisplay.layer.shadowOffset = CGSize(width: 0, height: 0)
            pointsDisplay.layer.shadowRadius = 5
            barDisplay.layer.shadowColor = UIColor.blackColor().CGColor
            barDisplay.layer.shadowOpacity = 0.1
            barDisplay.layer.shadowRadius = 5
            barDisplay.layer.shadowOffset = CGSize(width: 0, height: 5)
            
        }
    }

    
