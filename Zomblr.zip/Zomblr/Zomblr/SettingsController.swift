//
//  SettingsController.swift
//  Zomblr
//
//  Created by JR Cabansag on 5/17/15.
//  Copyright (c) 2015 JR. All rights reserved.
//

import UIKit
import Parse

class SettingsController: UIViewController {
    
    
    @IBOutlet weak var maxMilesField: UITextField!
    @IBAction func backButton(sender: AnyObject) {
        saveValues()
    }
    @IBOutlet weak var minMilesField: UITextField!
    @IBOutlet weak var breaksField: UITextField!
    @IBOutlet weak var settingsDisplay: UILabel!
    @IBOutlet weak var topBackground: UIImageView!
    var user: PFObject!
    var username = "alisonhau"
    var maxMiles = 0
    var minMiles = 0
    var breaks = 0
    override func viewDidLoad() {
        getUser()
        loadValues()
        updateDisplays()
        super.viewDidLoad()
    }
    func getUser(){
        var data = (PFQuery(className: "Users").findObjects() as? [PFObject])!
        var userIndex = NSUserDefaults.standardUserDefaults().integerForKey("Profile")
        username = data[userIndex]["Username"] as! String
        println(username)
    }
    func updateDisplays(){
        maxMilesField.text = String(maxMiles)
        minMilesField.text = String(minMiles)
        breaksField.text = String(breaks)
    }
    func saveValues(){
        if(maxMilesField.text != ""){
        user.setValue(maxMilesField.text.toInt()!, forKey: "MaxMiles")
        }
        if(minMilesField.text != ""){
        user.setValue(minMilesField.text.toInt()!, forKey: "MinMiles")
        }
        if(breaksField.text != ""){
        user.setValue(breaksField.text.toInt()!, forKey: "Breaks")
        }
        user.saveInBackground()
    }
    func loadValues(){
        user = PFQuery(className: "Users").whereKey("Username", equalTo: username).getFirstObject()
        maxMiles = user.valueForKey("MaxMiles") as! Int
        minMiles = user.valueForKey("MinMiles") as! Int
        breaks = user.valueForKey("Breaks") as! Int
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func createShadows(){
        settingsDisplay.layer.shadowColor = UIColor.blackColor().CGColor
        settingsDisplay.layer.shadowOffset = CGSize(width: 0, height: 0)
        settingsDisplay.layer.shadowRadius = 5
        settingsDisplay.layer.shadowOpacity = 0.22
        topBackground.layer.shadowColor = UIColor.blackColor().CGColor
        topBackground.layer.shadowOffset = CGSize(width: 0, height: 5)
        topBackground.layer.shadowRadius = 5
        topBackground.layer.shadowOpacity = 0.1
    }
}