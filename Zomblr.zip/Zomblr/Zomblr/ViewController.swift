import UIKit
import Parse

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    var filtered:[PFObject] = []
    var searchActive : Bool = false
    var data:[PFObject] = []
    var selectedUser : Int = 0
    var username = ""
    func getUser(){
        data = (PFQuery(className: "Users").findObjects() as? [PFObject])!
        var userIndex = NSUserDefaults.standardUserDefaults().integerForKey("Profile")
        username = data[userIndex]["Username"] as! String
        println(username)
    }
    
    override func viewDidLoad() {
        getUser()
        super.viewDidLoad()
        //self.signUp("hello2", password: "h11", email: "h21")
        //self.searchBar.delegate = self
        data = (PFQuery(className: "Users").findObjects() as? [PFObject])!
    }
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchActive = true;
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBar(searcBar: UISearchBar, textDidChange searchText: String) {
        filtered = data.filter({ (text) -> Bool in
            let tmp1: PFObject = text
            let tmp = tmp1["Username"]
            let range = tmp!.rangeOfString(searchText, options: NSStringCompareOptions.CaseInsensitiveSearch)
            return range.location != NSNotFound
        })
        if(filtered.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        tableView.reloadData()
    }
    
    func didReceiveMemoringWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func tableView(tableView: UITableView,
        didSelectRowAtIndexPath indexPath: NSIndexPath) {
            self.selectedUser = indexPath.row;
            NSUserDefaults.standardUserDefaults().setInteger(selectedUser, forKey: "Profile")
            NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    
    override func prepareForSegue(segue:UIStoryboardSegue!, sender: AnyObject!) {
        if (segue.identifier == "goToProfileSeg") {
            let svc = segue.destinationViewController as! ProfileController;
            let path = self.tableView.indexPathForSelectedRow()!
            svc.username = self.data[path.row]["Username"] as! String
        }
    }
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(searchActive) {
            return filtered.count
        }
        return data.count;
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("usernameTableCell") as! UITableViewCell;
        if(searchActive) {
            let temp = filtered[indexPath.row]
            cell.textLabel?.text = temp["Username"] as? String
        }
        else{
            let temp = data[indexPath.row]
            cell.textLabel?.text = temp["Username"] as? String;
        }
        return cell
    }
    
    func signUp(username: String, password: String, email: String){
        print("method called")
        if(isRealUser(username) == false && isDuplicateEmail(email) == false){
            let user = PFObject(className: "Users")
            user["Username"] = username.lowercaseString
            user["Password"] = password.lowercaseString
            user["Email"] = email.lowercaseString
            user["Miles"] = 0
            user["Points"] = 0
            user["Followers"] = []
            user.saveInBackgroundWithBlock { (success: Bool, error: NSError?) -> Void in
                println("Object has been saved.")
                self.data.append(user)
                print("data added")
            }
        }
    }
    
    func isRealUser(username: String) -> Bool{
        var userQuery = PFQuery(className: "Users")
        if(userQuery.whereKey("Username", equalTo: username.lowercaseString).countObjects() == 0){
            return false;
        }
        else{
            return true;
        }
    }
    
    
    
    func isDuplicateEmail(email: String) -> Bool{
        var userQuery = PFQuery(className: "Users")
        if(userQuery.whereKey("Email", equalTo: email.lowercaseString).countObjects() == 0){
            return false;
        }
        else{
            return true;
        }
    }
    
    func addFollower(userFollowing: String, userFollowed: String){
        if(isRealUser(userFollowing) && isRealUser(userFollowed)){
            var query = PFQuery(className: "Users").whereKey("Username", equalTo: userFollowed)
            var user = query.getFirstObject()
            var userFollowers = user?.valueForKey("Followers") as! Array<String>
            userFollowers.append(userFollowing)
            user?.setValue(userFollowers, forKey: "Followers")
            user!.saveInBackgroundWithBlock { (success: Bool, error: NSError?) -> Void in
                println("Object has been saved.")
            }
        }
        else{
            println("Invalid users!")
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}


