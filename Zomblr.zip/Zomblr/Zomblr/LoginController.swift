//
//  LoginController.swift
//  Zomblr
//
//  Created by JR Cabansag on 5/17/15.
//  Copyright (c) 2015 JR. All rights reserved.
//

import UIKit
import Parse

class LoginController: UIViewController, UITextFieldDelegate{
    
    @IBOutlet weak var useText: UITextField!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var passText: UITextField!
    //var data = PFQuery(className: "Users")
    var data:[PFObject] = []

    
    @IBAction func loginClicked(sender: AnyObject) {
        println("Send login!")
        var users = PFQuery(className: "Users")
        println(useText.text)
        var userQuery = users.whereKey("Username", equalTo: useText.text)
        if(userQuery.countObjects() == 1){
            var user = userQuery.getFirstObject()
            println(passText.text)
            println(user?.valueForKey("Password") as! String)
            if((user?.valueForKey("Password") as! String) == passText.text){
                println("SHOULD SWITHC!!!!!!!!!!!!")
                data = (PFQuery(className: "Users").findObjects() as? [PFObject])!
                var users = PFQuery(className: "Users")
                var user = users.whereKey("Username", equalTo: useText.text).getFirstObject()
                var temp = find(data, user!)
                println(temp)
                NSUserDefaults.standardUserDefaults().setInteger(temp!, forKey: "Profile")
                NSUserDefaults.standardUserDefaults().synchronize()
                println(temp)
                let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                let resultViewController = storyBoard.instantiateViewControllerWithIdentifier("ProgressControl") as! ProgressController
                
                self.presentViewController(resultViewController, animated:true, completion:nil)
                
            }
        }
        var username = useText.text
        var password = passText.text
        // check username and password
        // sign in if u and p are correct
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.useText.delegate = self
        self.passText.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
        let testObject = PFObject(className: "TestObject")
        //        testObject["foo"] = "bar"
        //        testObject.saveInBackgroundWithBlock { (success: Bool, error: NSError?) -> Void in
        //            println("Object has been saved.")
        //        }
    }
    
//    override func prepareForSegue(segue:UIStoryboardSegue!, sender: AnyObject!) {
//        if (segue.identifier == "logInSeg") {
//            let svc = segue.destinationViewController as! ProgressController;
//            svc.username = useText.text as String
//        }
//    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
}

