//
//  NotificationsController.swift
//  Zomblr
//
//  Created by JR Cabansag on 5/16/15.
//  Copyright (c) 2015 JR. All rights reserved.
//

import UIKit
import Parse

class NotificationsController: UIViewController{
    
    @IBOutlet weak var notificationstitleDisplay: UILabel!
    @IBOutlet weak var notificationsDisplay: UIScrollView!
    @IBOutlet weak var topBackground: UIImageView!
    var username = "alisonhau"
    
    func getUser(){
        var data = (PFQuery(className: "Users").findObjects() as? [PFObject])!
        var userIndex = NSUserDefaults.standardUserDefaults().integerForKey("Profile")
        username = data[userIndex]["Username"] as! String
        println(username)
    }
    
    override func viewDidLoad() {
        getUser()
        createShadows()
        displayNotifications()
        super.viewDidLoad()
    }
    func displayNotifications(){
        var users = PFQuery(className: "Users")
        var notifications = users.whereKey("Username", equalTo: username).getFirstObject()!.valueForKey("Notifications") as! Array<String>
        if(notifications.count != 0){
            notificationsDisplay.contentSize = CGSize(width: 320, height: 16+91*notifications.count)
            for var i = 0; i < notifications.count; i++
            {
                var notification = notifications[i]
                var miniArray = notification.componentsSeparatedByString("~")
                createNotification(miniArray[0], type: miniArray[1], date: miniArray[2], index: i)
            }
        }
    }
    func createNotification(user: String, type: String, date: String, index: Int){
        var notificationView = UIView(frame: CGRect(x: 16, y: 16+91*index, width: 288, height: 75))
        notificationView.backgroundColor = UIColor.whiteColor()
        notificationView.layer.shadowColor = UIColor.blackColor().CGColor
        notificationView.layer.shadowOffset = CGSize(width: 0, height: 0)
        notificationView.layer.shadowOpacity = 0.1
        notificationView.layer.shadowRadius = 5
        var title = ""
        var message = ""
        var notificationImage = UIImageView(image: UIImage(named: "NotificationImage"))
        if(type == "follow"){
            title = "new zombie!"
            message = user+" started crawling after you!"
            notificationImage = UIImageView(image: UIImage(named: "NotificationFollowImage"))
        }
        if(type == "like"){
            title = "new bite!"
            message = user+" bit your status!"
            notificationImage = UIImageView(image: UIImage(named: "NotificationLikeImage"))
        }
        if(type == "comment"){
            title = "new comment!"
            message = user+" groaned about your status!"
            notificationImage = UIImageView(image: UIImage(named: "NotificationCommentImage"))
        }
        var messageView = UILabel(frame: CGRect(x: 75, y: 35, width: 0, height: 0))
        messageView.text = message.uppercaseString
        messageView.sizeToFit()
        messageView.font = UIFont(name: "Century Gothic", size: 9)
        messageView.textColor = UIColor(red:0.71, green:0.71, blue:0.71, alpha:1.0)
        notificationImage.frame = CGRect(x: 15, y: 15, width: 45, height: 45)
        notificationImage.layer.shadowColor = UIColor.blackColor().CGColor
        notificationImage.layer.shadowOffset = CGSize(width: 0, height: 0)
        notificationImage.layer.shadowOpacity = 0.1
        notificationImage.layer.shadowRadius = 5
        var titleView = UILabel(frame: CGRect(x: 75, y: 20, width: 0, height: 0))
        titleView.text = title.uppercaseString
        titleView.sizeToFit()
        titleView.font = UIFont(name: "CenturyGothic-BoldItalic", size: 15)
        titleView.textColor = UIColor(red:0.52, green:1.00, blue:1.00, alpha:1.0)
        var dateView = UILabel(frame: CGRect(x: 210, y: 7, width: 0, height: 0))
        dateView.text = date.uppercaseString
        dateView.sizeToFit()
        dateView.font = UIFont(name: "Century Gothic", size: 9)
        dateView.textColor = UIColor(red:0.77, green:0.77, blue:0.77, alpha:1.0)

        notificationsDisplay.addSubview(notificationView)
        notificationView.addSubview(notificationImage)
        notificationView.addSubview(messageView)
        notificationView.addSubview(titleView)
        notificationView.addSubview(dateView)
    }
    func createShadows(){
        notificationstitleDisplay.layer.shadowColor = UIColor.blackColor().CGColor
        notificationstitleDisplay.layer.shadowOffset = CGSize(width: 0, height: 0)
        notificationstitleDisplay.layer.shadowRadius = 5
        notificationstitleDisplay.layer.shadowOpacity = 0.22
        topBackground.layer.shadowColor = UIColor.blackColor().CGColor
        topBackground.layer.shadowOffset = CGSize(width: 0, height: 5)
        topBackground.layer.shadowRadius = 5
        topBackground.layer.shadowOpacity = 0.1
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
